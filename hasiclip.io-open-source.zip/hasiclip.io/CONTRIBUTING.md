# Contributing to hasiclip.io

Thanks for considering a contribution.

## Ways to contribute
- Report reproducible bugs.
- Improve mobile accessibility and usability.
- Improve Urdu/English wording and prompts.
- Add translations.
- Suggest privacy and data-portability improvements.
- Submit focused code changes.

## Before opening a pull request
1. Explain the problem or improvement.
2. Keep the app usable without paid services or API keys.
3. Do not add private API keys, credentials, or personal data.
4. Test the app on a phone-sized screen and a desktop browser.
5. Check that project save, switching, deletion, backup export/import, and step navigation still work.
6. Update README.md if behavior or privacy changes.

## Local testing
Open `index.html` in a modern browser. No build step is required.
