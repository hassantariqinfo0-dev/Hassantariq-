# Privacy notes

The current version is a static client-side application.

- Project titles, notes, progress, and completion flags are stored in the browser's localStorage.
- This data is not transmitted to a hasiclip.io backend by this app.
- Exported JSON backups are files you control.
- Browser storage can be cleared by the user, browser settings, or device cleanup tools.
- Third-party links open external services. Their privacy policies and terms apply when you use them.
- Never put passwords, API secrets, or sensitive personal information into project notes.

Future contributors must update this document if they introduce analytics, remote storage, AI APIs, cookies, or other data transmission.
