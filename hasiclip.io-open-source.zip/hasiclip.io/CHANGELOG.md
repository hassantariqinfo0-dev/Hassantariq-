# Changelog

## 1.0.0 — 2026-11-07
- Rebranded the original MindShift AI Studio workflow as hasiclip.io.
- Preserved the original 10-stage creator workflow and prompt-based approach.
- Added multiple projects, per-step notes, completion tracking, and progress display.
- Added JSON backup export and import.
- Added previous/next navigation and safer clipboard fallback.
- Added privacy, limitations, contribution, and licensing documentation.
