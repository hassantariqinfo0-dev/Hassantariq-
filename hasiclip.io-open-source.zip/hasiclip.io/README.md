# hasiclip.io

**A free, open-source creator workflow for planning short-form videos.**

Created by **Hassan Tariq**. Licensed under the **MIT License**.

## What it does

hasiclip.io organizes a 10-step short-form video workflow:

1. Research
2. Urdu script
3. AI voice-over preparation
4. Footage planning
5. Editing plan
6. Thumbnail concept
7. Subtitles
8. YouTube SEO
9. Upload checklist
10. Analytics review

It includes multiple local projects, per-step notes, completion tracking, and JSON backup import/export.

## What it does not do

This repository is a static browser-based workflow organizer. It does **not** currently:
- connect to an AI model or API;
- generate audio, images, or videos;
- automatically upload, schedule, or publish videos;
- connect to YouTube Analytics.

The prompt buttons prepare text for use with AI and creator services. Third-party services may charge fees and have their own terms.

## Project name and domain note

The GitHub repository name `hasiclip.io` does not automatically register or provide ownership of the internet domain `hasiclip.io`. A custom domain requires separate domain registration and DNS configuration. GitHub Pages can first publish the project at its generated `github.io` address.

## Run it

No build tools or package installation are required.

### Option 1: Open locally
Download or clone this repository and open `index.html` in a modern browser.

### Option 2: GitHub Pages
1. Create a public GitHub repository named `hasiclip.io`.
2. Upload the files in this repository to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. The Pages URL will appear in that settings screen.

## Data and privacy

- Projects and notes are stored in the browser's `localStorage` on the device/browser being used.
- The app does not send project data to a hasiclip.io server.
- Clearing browser website data may erase local projects.
- Use **Export backup (.json)** to save a copy before changing devices or clearing browser data.
- Do not store passwords, API secrets, or sensitive personal information in project notes.

If you add remote AI services in a future version, do not place private API keys in front-end JavaScript. Use a secure server-side integration and document the data flow.

## Contributing

Bug reports, accessibility improvements, translations, prompt improvements, and code contributions are welcome. See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

This project is released under the MIT License. See [LICENSE](LICENSE).

## Credits

Created by Hassan Tariq. hasiclip.io is an independent project and is not affiliated with YouTube, Google, OpenAI, ElevenLabs, CapCut, Canva, Pexels, Pixabay, or vidIQ.
